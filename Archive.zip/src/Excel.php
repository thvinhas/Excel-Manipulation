<?php

namespace src;
require '../vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use \PhpOffice\PhpSpreadsheet\Reader\Xlsx;

class Excel {
    private $file;
    private $worksheet;
    private $xls;


    public function __construct($file) {
        $this->file = $file;
        $xls = new Xlsx();
        
    }

    public function readFile () {
        $teste =  $this->xls->load($this->file);
        $this->worksheet = $teste->getActiveSheet();
        $dataArray = $this->worksheet->toArray();

        var_dump($dataArray);
    }
}